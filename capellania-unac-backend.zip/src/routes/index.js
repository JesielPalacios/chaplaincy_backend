import Router from 'express'

import authRoutes from './auth.routes'
import userRoutes from './user.routes'
import customersRoutes from './customers.routes'
import photoRoutes from './photo.routes'
import matterCancellationRoutes from './matterCancellation.routes'

let router
router = Router(router)

router.use('/auth', authRoutes)
router.use('/', userRoutes)
router.use('/', customersRoutes)
router.use('/', photoRoutes)
router.use('/', matterCancellationRoutes)

export default router
