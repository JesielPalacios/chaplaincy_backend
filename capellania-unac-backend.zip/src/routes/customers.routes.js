import Router from 'express'
import customerCtrl from '../controllers/customer.controller'
import { verifyJwt, authJwt } from '../middlewares'

let router
router = Router(router)

router
  .route('/customers')

  // GET ALL CUSTOMERS
  .get([verifyJwt, authJwt(['admin'])], customerCtrl.getAllCustomers)

  // CREATE A NEW CUSTOMER
  .post([verifyJwt, authJwt(['admin'])], customerCtrl.createNewCustomer)

router
  .route('/customer/:id')

  // GET ONE CUSTOMER BY ID
  .get([verifyJwt, authJwt(['admin'])], customerCtrl.getOneCustomerById)

  // UPDATE ONE CUSTOMER BY ID
  .put([verifyJwt, authJwt(['admin'])], customerCtrl.updateOneCustomerById)

  // DELETE ONE CUSTOMER BY ID
  .delete([verifyJwt, authJwt(['admin'])], customerCtrl.deleteOneCustomerById)

export default router
