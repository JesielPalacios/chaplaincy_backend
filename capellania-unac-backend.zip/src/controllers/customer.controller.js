import CustomerSchema from "../models/Customer";
import CryptoJS from "crypto-js";

export function encryptPassword(passwordToEncrypt) {
  return CryptoJS.AES.encrypt(
    passwordToEncrypt,
    process.env.PASS_SEC
  ).toString();
}

/**
 * Controlador para obtener todos los usuarios de la base de datos.
 *
 * @constructor
 * @param {Request} req - Objeto de petición.
 * @param {Response} res - Objeto de respuesta de la petición.
 */

async function getAllCustomers(req, res) {
  const query = req.query.new;

  try {
    const customers = query
      ? await CustomerSchema.find().sort({ _id: -1 }).limit(5)
      : await CustomerSchema.find();

    if (customers.length === 0)
      res.status(204).json({ message: "There aren't customers" });
    else res.status(200).json(customers);
  } catch (err) {
    res.status(500).json(err);
  }
}

async function createNewCustomer(req, res) {
  if (
    !(
      req.body.firstName ||
      req.body.firstSurname ||
      req.body.citizenshipNumberId ||
      req.body.studentCode ||
      req.body.semester ||
      req.body.email ||
      req.body.dateOfBirth ||
      req.body.birthCountry ||
      req.body.birthDepartment ||
      req.body.birthCity
    )
  ) {
    return res.status(400).json({ message: "Some info is missing" });
  }

  if (req.files === null) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  req.body.userCreate = req.user.id;
  req.body.userUpdate = req.user.id;
  req.body.password = encryptPassword(req.body.password);

  try {
    const file = req.files.file;
    file.name = uuid() + file.name;
    
    const newPhoto = new PhotoSchema({
      imagePath: "/uploads/" + file.name,
      userCreate: req.user.id,
      userUpdate: req.user.id,
      photoSubject: req.body._id
    });
    const savedPhoto = await newPhoto.save();
    
    const newCustomer = new CustomerSchema({
      ...req.body,
      photoUser: savedPhoto._id,
    });

    const savedCustomer = await newCustomer.save();

    res.status(201).json(savedCustomer);
  } catch (err) {
    res.status(500).json(err);
  }
}

async function getOneCustomerById(req, res) {
  try {
    const customer = await CustomerSchema.findById(req.params.id);
    const { password, ...others } = customer._doc;
    res.status(200).json(others);
  } catch (err) {
    res.status(500).json(err);
  }
}

async function updateOneCustomerById(req, res) {
  if (req.body.password) req.body.password = encryptPassword(req.body.password);

  try {
    const updatedCustomer = await CustomerSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    res.status(200).json(updatedCustomer);
  } catch (err) {
    res.status(500).json(err);
  }
}

async function deleteOneCustomerById(req, res) {
  try {
    await CustomerSchema.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: "Customer has been deleted..." });
  } catch (err) {
    console.log(err);
    res.status(500).json(err);
  }
}

export default {
  getAllCustomers,
  createNewCustomer,
  getOneCustomerById,
  updateOneCustomerById,
  deleteOneCustomerById,
};
